## 배포 환경 MSA 애플리케이션 공통 리소스 정의 - Secret

- **Secret 이름**: `gift-secret`
  - `JWT_SECRET`: `WW4ya2ppYmRkRkFXdG5QSjJBRmxMOFdYbW9oSk1DdmlnUWdnYUV5cGE1RT0=`
  - `KAKAO_CLIENT_ID`: `YWMyMGQ4NGY5N2I2NzlmMGJiZDlhODA2NWJhODIzZjM=`
  - `KAKAO_CLIENT_SECRET`: `RnczSmlMNVBrcGV2WFZaOU9pVk04YmZiZ0hVUEQ1RUE=`